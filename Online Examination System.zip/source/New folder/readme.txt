---------------------------------------------HOW TO RUN PROGRAM--------------------------------------------------



python manage.py migrate
Create a Superuser by executing the following command:
python manage.py createsuperuser
Run the project by executing the following command:
python manage.py runserver
Keep the terminals open and running.
